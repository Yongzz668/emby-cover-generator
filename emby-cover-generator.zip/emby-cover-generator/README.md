# Emby Cover Generator

This project provides a frontend UI and backend Worker for generating media covers.